// go get -u github.com/tencentyun/tcecloud-sdk-go
// package github.com/tencentyun/tcecloud-sdk-go: no Go files in /Users/xxx/go/src/github.com/tencentyun/tcecloud-sdk-go
// FIXME: this is a workaround for above go get issue, a fake file does nothing but claims we are a go project.
// Eventually we need something useful here, such as real documentation, version and etc.
package doc
